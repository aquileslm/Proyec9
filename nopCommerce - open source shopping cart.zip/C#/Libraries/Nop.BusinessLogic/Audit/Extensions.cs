//------------------------------------------------------------------------------
// The contents of this file are subject to the nopCommerce Public License Version 1.0 ("License"); you may not use this file except in compliance with the License.
// You may obtain a copy of the License at  http://www.nopCommerce.com/License.aspx. 
// 
// Software distributed under the License is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. 
// See the License for the specific language governing rights and limitations under the License.
// 
// The Original Code is nopCommerce.
// The Initial Developer of the Original Code is NopSolutions.
// All Rights Reserved.
// 
// Contributor(s): _______. 
//------------------------------------------------------------------------------

using System.Collections.Generic;

namespace NopSolutions.NopCommerce.BusinessLogic.Audit
{
    /// <summary>
    /// Extensions
    /// </summary>
    public static class Extensions
    {
        /// <summary>
        /// Find activity log type by system keyword
        /// </summary>
        /// <param name="source">Source</param>
        /// <param name="systemKeyword">The system keyword</param>
        /// <returns>Activity log type item</returns>
        public static ActivityLogType FindBySystemKeyword(this List<ActivityLogType> source,
            string systemKeyword)
        {
            for (int i = 0; i < source.Count; i++)
                if (source[i].SystemKeyword.ToLowerInvariant().Equals(systemKeyword.ToLowerInvariant()))
                    return source[i];
            return null;
        }
    }
}
